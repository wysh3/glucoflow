# Desktop engineering: the long form

The reasoning and worked detail behind the summarized sections of [`AGENTS.md`](./AGENTS.md). The
rules themselves are in `AGENTS.md`, which agents load automatically; this file is read on purpose.

## Identity is not incidental

Sessions have more than one identity, and conflating them is a recurring source
of "session not found" and vanishing history. Reason about which identity a
surface needs: durable navigation and anything the user pins or persists key off
the stable/durable identity; live streaming keys off the runtime identity; state
that must outlive compression keys off the lineage root. Keep the mapping between
them explicit and translate at the boundary rather than passing the wrong id
inward.

Two guarantees follow from this (#111868). The user's message is durable at
send: `prompt.submit` writes the session row AND the user row before the agent
build starts, and the turn adopts that row (`_adopt_submit_user_row` →
`agent._pending_cli_user_message`) instead of appending a second one, so a
freeze or force-quit during a slow first build leaves a resumable transcript
(user message present, no reply). And renderer state keyed by profile name —
persisted tabs (`tilesByProfile`), Bot tile owner routes, cached transcript
tails, remembered session/route, session owner hints — follows a profile
rename via `migrateTilesForProfile(old, new)` (`store/session-states.ts`), the
rename sibling of `dropTilesForProfile`. Add any new profile-keyed localStorage
family to BOTH, or a rename leaves it pointing at a backend that no longer
exists ("Couldn't open this session" on every restore).

When an id is verifiably gone anyway (`goneSessionVerdict` → `'draft'`), the
window drops to a fresh draft without toasting or looping — and the unsent
text stashed under the dead key follows it: the verdict calls
`announceGoneSessionDraft(id)` and the composer's swap onto the fresh scope
consumes it once (`adoptGoneSessionDraft`, `store/composer.ts`), seeding the
composer and publishing the inline, undoable `$restoredDraftNotice`. Offer,
don't hijack: no navigation beyond the drop itself, no focus steal, no toast,
and an already non-empty fresh draft is never clobbered.

## Server truth is cached, not owned

The renderer paints from a cache of backend truth, so it must reconcile, not
assume:

- **Merge, don't clobber.** A refresh is new information layered over what you
  already know, not a replacement that can drop live or pinned rows.
- **Be optimistic, then honest.** Direct manipulation should paint immediately
  from a snapshot; a failed write rolls back visibly and an authoritative
  refresh gets the last word.
- **Guard against the past.** Async results can arrive out of order; a stale
  response must never overwrite newer intent. Generation counters and request
  tokens exist for this.
- **Isolate the foreground.** Only the surface the user is looking at may publish
  into the shared view; background work updates its own cache quietly.
- **Coalesce noise, flush signal.** Batch high-frequency cosmetic updates, but
  let terminal transitions (a turn finishing, needing input, failing) reach the
  user immediately.
- **Preserve reference identity on no-ops.** Handing React a fresh array that
  contains the same data re-renders expensive trees for nothing.

## Voice detection follows audio, not paint

Microphone endpointing and barge-in detection use `voice-level-meter.ts` and its
AudioWorklet's audio timestamps. Never put functional detection back on
`requestAnimationFrame`, or keep a whole window painting to make voice work.
The worklet reports at 60 Hz and preserves the 256-sample byte-domain RMS scale
used by existing sensitivity preferences. Its output is silent; it does not
play microphone input through the speakers. Hidden windows skip cosmetic
meter-state updates, not speech detection or PCM capture.

Do not report listening or start MediaRecorder until the meter's `ready` promise
settles. Cancellation settles pending readiness immediately and cannot restart
capture or reacquire a dictation lease. A turn that becomes busy during startup
re-arms listening when it returns idle.

The capture owner closes its AudioContext through `mic-meter-context.ts`.
Stopping the meter fences pending module loads and queued samples. A failed
meter must release a pending conversation capture without transcribing a
potentially truncated command; explicit cancellation delivers nothing.
Detach recorder handlers even after `stop()` has made the recorder inactive:
its final events can still be queued.
Resume an initially suspended context independently of worklet loading so a
failed meter preserves manual recording and the PCM fallback. Once running,
a suspended audio clock is a meter failure: release a pending barge capture
without submitting partial audio rather than waiting for silence that cannot arrive.

Process queued audio levels in order, including historical speech. Rotate quiet
pre-roll or end capture only when the audio clock is still inside that sample's
reporting interval. The worklet supplies the next report timestamp, including
frame rounding; a delayed quiet sample must not discard already-recorded speech
that its queued successors have not reported yet. Cancellation and meter-failure
cleanup do not wait for a fresh sample.
Playback state is observed at delivery time: use the current audio clock for
playback-onset grace and gap bookkeeping, never a queued sample's historical
timestamp. Queued samples preceding the observed stop retain the playback
threshold; new quiet-room speech uses the ordinary lower threshold. Speech
windows still use capture time. Forward that capture-phase playback flag to the
conversation's echo guard, which must still reject speaker bleed delivered
during a later sentence gap without discarding genuine interruptions.

The worklet is a Vite-emitted local asset, not a blob/data-URL fallback or a
reason to weaken CSP. This removes a paint-clock dependency, not the main
thread's role in handling voice messages. It does not change native window
scheduling or establish a GPU/battery improvement percentage.

## Switching context is a re-home, not a reboot

Changing profile, connection, or mode is a workspace switch, not a cold start.
The shell and whatever the user was doing stay put; only the gateway-bound view
is cleared and repopulated, and the previous context must not leak into the next
one. Reserve the full-screen boot/connecting experience for a genuinely unusable
backend.

There are three distinct switch shapes, and conflating them is the classic bug:

- A **connection/mode apply** (local ↔ remote ↔ cloud) is the soft re-home:
  shell mounted, gateway-bound stores explicitly wiped, then reconnect. Query
  invalidation alone cannot evict live session stores — wipe them.
- A **runtime home change** (switching the underlying `HERMES_HOME` profile) is
  a hard re-home: the window legitimately reloads and state resets by remount.
- A **live profile swap** in the same window activates another profile's socket
  while background profiles keep streaming; lists merge rather than wipe, and
  only an explicit user selection starts a fresh foreground draft.

Treating a soft switch as hard flickers the app; treating a hard one as soft
strands stale rows. After any swap, the active socket, active profile, and
connection atoms must agree, or REST and filesystem calls route to the wrong
backend.

## Cross everything as an observable ladder

Desktop lives at the seams: versions, profiles, local vs remote vs cloud,
partially installed runtimes, stale caches, older backends. The durable technique
for all of it is the same — an ordered ladder of candidates:

1. Precedence is written down, in one place, as data or a pure function.
2. A candidate is trusted only after it is validated at the right boundary.
   Existence is not proof; probe what you're about to rely on.
3. A failed _read_ falls to the next rung; a failed _authoritative write_
   surfaces or rolls back rather than silently retargeting.
4. A missing capability and a transient failure are different: the first may
   enable a compatibility path or a disabled state; the second should retry.
5. Retries are bounded and end in a real recovery affordance — never an infinite
   spinner or a hot loop.
6. One resolver owns each policy so every caller gets the same answer. Scatter is
   how two call sites drift apart.

This is the shape of backend discovery, command/version fallbacks, connection and
auth resolution, workspace-cwd selection, capability detection, and preview
normalization alike. Learn the shape, not a snapshot of the current rungs.

Two auth-flavored corollaries worth naming because they are easy to get wrong:

- **One-time credentials are never reused.** An OAuth gateway connection mints a
  fresh WebSocket ticket on every dial and never falls back to the cached URL.
  Only a confirmed 401/403 (or an explicitly tagged auth rejection) means
  reauthentication; timeout, network, malformed-response, and server failures
  remain connectivity errors. Only long-lived token/local auth may reuse a
  cached URL as a lower rung.
- **A connection test must exercise the leg you'll actually use.** An HTTP
  status probe passing while the WebSocket/auth leg fails is a false positive
  that ships as "it said connected but nothing works."
- **Cookie-jar partition names contain nothing Electron percent-escapes.** A
  `persist:` partition becomes a `Partitions/<escaped name>` folder; a folder
  name with `%3A` (an escaped `:`) gets a cookie store Windows can neither read
  nor write, so the session silently never persists. `electron/oauth-partition.ts`
  pins the invariant; renaming a partition signs its users out once — say so.

## Guest content never opens anything by itself

Untrusted HTML runs in two places: sandboxed `allow-scripts` iframes (artifact
previews) and the preview pane's `<webview>` (`persist:hermes-preview`). Neither
may drive the OS browser without the user's hand on it (GHSA-9f4c-93c8-jc8g):
`setWindowOpenHandler` denies everything and never opens a URL as a side
effect (`electron/window-open-policy.ts`), and the webview has no
`allowpopups` — do not add it.

A guest page's `target="_blank"` links (Streamlit's "Ask Google" traceback
button) reach the OS browser through one explicit bridge instead:

- `main.ts` installs `electron/preview-guest-preload-entry.ts` via
  `will-attach-webview`, keyed on the `persist:hermes-preview` partition only.
  It is the app's only guest preload; a new webview does not inherit it unless
  it opts into that partition.
- The preload runs in the isolated world, exposes nothing to the page, and
  forwards only a **trusted** (`event.isTrusted`) primary-button click on an
  `a[target="_blank"]` to the host via `ipcRenderer.sendToHost`. A synthetic
  `dispatchEvent(click)` from page script is dropped there; page `window.open`
  stays blocked.
- `PreviewPane` admits `http:`/`https:` only (`src/lib/preview-external.ts`)
  and hands the URL to the existing `hermes:openExternal` IPC, which applies
  main's URL policy. `file:` is excluded on purpose: a guest must never reach
  `shell.openPath`.

Widening any of those three (partition key, trusted-click gate, scheme set)
reopens the gesture-less forced-navigation class the advisory closed.

## Rendering work follows visibility and ownership

- Live transcript navigation reads the session store; the shared navigation
  context carries only the selected historical page, not every streamed delta.
- Hidden terminals stay mounted and keep parsing output. Suppress only their
  DOM rows, not the measurable host/helpers or terminal state. Do not reduce
  scrollback or replace parser state to save painting work. Unchanged retained
  snapshots must not republish the terminal store.
  Register an agent-terminal writer before recovering its matching process
  snapshot. A quiet tab can reopen after cold eviction without any new registry
  notification; recovery must not duplicate live output or exempt cold entries
  from the retention budget.
- Root geometry variables are not theme changes. Authored custom CSS can depend
  on those variables, so it must retain full repaint notifications.
- Streaming keeps visible native windows painting even while blurred or occluded.
  Hidden/minimized windows retain default throttling; show/restore reapplies the
  current stream policy. Do not use focus as visibility or stop background data
  delivery. Native activity leases can wake a hidden owner without restoring it.
  Only window-local live voice conversations retain streaming paint: their speech
  output still consumes frame-published text, even though microphone detection
  follows the audio clock. The shared read-aloud preference is not ownership.
  Completed interim replies publish without waiting for a frame so read-aloud
  can speak tool-progress narration while hidden; partial text stays coalesced.
  Interims and finals that arrive before ownership IPC settles share the pending
  turn claim; message claims stay distinct so only the newest eligible reply plays.
- Functional stream deadlines are not display loops. Delta coalescing and the
  400 ms post-commit journal debounce use `src/lib/stream-work-clock.ts`, racing
  the ordinary renderer timer with one pending native wake per owning renderer.
  Incoming events can also drain overdue work; they cannot finish a quiet tail.
  Do not replace the native fallback with rAF or re-enable hidden painting.
- `electron/stream-work-clock.ts` accepts only bounded relative delays from the
  owning window's main frame. Cancellation/generation tokens fence late wakes;
  navigation, renderer loss and destruction clear native work. No pending work
  means no wake timer. This preserves coalescing, not a real-time crash-loss bound
  through blocked event loops, storage failures or OS sleep.
- Stop commits already-received queued deltas before marking the turn interrupted.
  Journal snapshots must continue advancing while display callbacks are parked.
  Verify the quiet tail with the provider paused, not only a continuously arriving
  stream that can hide a throttled-timer bug.
- Idle preview guests use Chromium's background throttling. Owned activity
  leases wake the guest and its embedding window; the window controller still
  arbitrates streaming and Wayland fullscreen policy. One operation finishing
  must not suspend overlapping work.
  Registration belongs in `electron/preview-guest-ipc.ts`; `main.ts` only binds
  the owner-window wake callback. Keep validation and ownership checks at that IPC boundary.
- Main owns script readiness, dispatch and document cancellation. Work queued
  during navigation belongs to the incoming page; a promise abandoned in the
  old document must release its lease. The first lease owns a navigation listener
  that re-wakes replacement widgets until the last lease ends, even without a
  new script. Reapply again at script dispatch after loading as a backstop:
  Electron's stored throttling flag does not prove a replacement widget is awake.
  Preserve the existing script completion-value contract and plugin consent.
  Registered preview reads must use the same owned script lease; a direct
  `webview.executeJavaScript` call bypasses hidden-window readiness guarantees.
  First-party page reads have an eight-second deadline and abort when their
  reader registration is removed, so a stalled page cannot retain a wake hold.
- Capture leases cover paint waits and image capture, not waiting for a user's
  next annotation. Keep action acquisition cancellable and bounded without
  imposing an arbitrary deadline on approved plugin scripts or long typing.
  Annotation capture shares one eight-second deadline across acquisition, paint,
  viewport lookup, native capture and cleanup. Stop, conversation changes and
  committed document navigation abort that lifetime and fence late drafts.
  A cancelled load or download keeps the existing document's annotation session.
  Overlay installation shares that abort lifetime; guest-side session ownership
  fences queued installation and teardown so cancellation cannot leave an
  invisible click interceptor or remove a replacement annotation session.
- Approved plugin scripts deliberately retain the guest **and owner window**
  wake exemption for their entire pending result. A promise that never settles
  can therefore keep the hidden app at full timer cadence indefinitely. There
  is no wake cap: dropping the wake while preserving the pending result could
  strand legitimate scripts waiting for rAF. Settlement or cancellation releases
  the lease; committed guest navigation cancels dispatched old-document scripts,
  pane unmount cancels its runner, and owner navigation or either renderer's
  destruction/crash retires the affected leases. Hiding a pane alone is not cancellation.

Verify scheduling changes with native hidden/minimized windows and real preview
navigation, typing and capture. Browser automation's focus emulation can keep
hidden frames awake and conceal regressions; disable it for these checks.
Software-rendered VM timings are not hardware GPU or battery measurements.
With a graphical session (or Xvfb), `npm run test:preview-activity-native
--workspace apps/desktop` exercises real hidden-frame navigation (including
lease-only rAF and capture), overlapping operations, cancellation and plugin
completion values in a disposable profile. Add `-- --minimized` with a running
window manager to exercise actual iconification rather than hiding the window.

## Nous free tier: state is pulled, never latched in the renderer

The free tier (a Nous identity with no account, `hermes_cli/anon_auth.py`) reaches the renderer
through one JSON-RPC pair: `free_tier.status` (has_guest, enabled, available,
notice_pending, model, label) read from local auth state with zero network, and
`free_tier.ack_notice`, which persists the one-time notice flag on the identity itself. The
first-launch ready screen and the own-key strip are the SAME state rendered for two situations,
keyed on `notice_pending`; there is no localStorage latch, so the CLI and the desktop cannot
disagree about whether the notice was shown. Sign-in goes through the existing
`POST /api/providers/oauth/nous/start` + poll route, which the dialog long-polls (`?wait=`: the
backend answers once the session leaves `pending`; the loop never asks again sooner than 2 s, so an
older backend that answers at once is not hammered). On completion it reports `reason`,
`account_email`, `model` and `handoff_status` (what the replaced free tier's apps did, with the
backend's own copy in `lines`); a move still retrying is followed through the
`/api/providers/oauth/nous/handoff` long-poll until it settles or the dialog closes. Every entry
point (Billing, status chip, ready screen) opens the one free-tier sign-in dialog, and a Nous sign-in
from the onboarding picker that moved apps shows the same result screen once onboarding leaves the
screen (onboarding paints above every dialog). Never branch on
provider display names: the picker row carries `free_tier_row`, status cards carry `free_tier`.
